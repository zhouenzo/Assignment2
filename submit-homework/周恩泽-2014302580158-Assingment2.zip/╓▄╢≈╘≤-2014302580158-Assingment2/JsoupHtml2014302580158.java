package jsoupHtml;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import jsoupHtml.HttpRequest;

public class JsoupHtml2014302580158 {

	public static void main(String[] args) throws IOException {
		// TODO �Զ����ɵķ������
        //��ȡһ����ʦ�ĸ�����ҳ
		String url="http://web.xidian.edu.cn/jfzhu/";//��ȡ��ַ
		HttpRequest response=HttpRequest.get(url).header("Cookie","visit_0=1");//����һ������
		response.receive(new File("teacher.html"));
		//����readhtml����
		String filepath="D:/workspace/eclipse-java-mars-R-win32/eclipse/workspace/jsoupHtml/teacher.html";
		readhtml(filepath);
		
		
	}
	
	public static void readhtml(String filepath) throws IOException{
		File input=new File(filepath);
		
			Document doc=Jsoup.parse(input,"UTF-8","http://web.xidian.edu.cn/jfzhu/");
			FileWriter text=new FileWriter("text.txt");
			
			
			/*Elements links1 = doc.select("div#dom0");
			Elements links2 = doc.select("div#dom1");
			
			
			for(Element link:links1){
				String linktext = link.text();
				text.write(linktext);
				text.write("\r\n");
			}
			for(Element link:links2){
				String linktext = link.text();
				text.write(linktext);
				text.write("\r\n");
			}*/
			Elements links1= doc.select(" span#t0 ");
			for(Element link:links1){
				String linktext = link.text();
				text.write(linktext);
				text.write("\r\n");
			}
			Elements links2 = doc.select(" div#n0 ");
			for(Element link:links2){
				String linktext = link.text();
				text.write(linktext);
				text.write("\r\n");
			}
			Elements links3 = doc.select(" span#t2 ");
			for(Element link:links3){
				String linktext = link.text();
				text.write(linktext);
				text.write("\r\n");
			}
			Elements links4 = doc.select(" div#n2 ");
			for(Element link:links4){
				String linktext = link.text();
				text.write(linktext);
				text.write("\r\n");
			}
			
			Elements links5 = doc.select(" span#t3 ");
			for(Element link:links5){
				String linktext = link.text();
				text.write(linktext);
				text.write("\r\n");
			}
			Elements links6 = doc.select(" div#n3");
			for(Element link:links6){
				String linktext = link.text();
				text.write(linktext);
				text.write("\r\n");
			}
			Elements links7 = doc.select(" span#t1");
			for(Element link:links7){
				String linktext = link.text();
				text.write(linktext);
				text.write("\r\n");
				}
			Elements links8 = doc.select(" div#n1");
			for(Element link:links8){
				String linktext = link.text();
				text.write(linktext);
				text.write("\r\n");
			}
			
			
			text.close();
			
			
		
		
		
	}

}

