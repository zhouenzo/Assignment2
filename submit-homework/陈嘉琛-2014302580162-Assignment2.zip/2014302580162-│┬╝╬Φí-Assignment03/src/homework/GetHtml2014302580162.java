package homework;

import homework.HttpRequest;

import java.io.File;



public class GetHtml2014302580162 {
	public static void main(String[] args) {
String url = "http://userweb.swjtu.edu.cn/Userweb/soar1120/index.htm";
		
		HttpRequest response = HttpRequest.get(url).header("Cookie","safedog-flow-item=0112B2CF6518B2DE0ED1077886332E54");
		
		response.receive(new File("zhuye.html"));
		}
}

