package homework;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * ����html
 * @author Aron
 *
 */
public class Main2014302580162 {
	public static void main(String[] args) throws IOException{
		File inputFile = new File("zhuye.html");
		Document doc = Jsoup.parse(inputFile,"gbk");
		Elements links = doc.getElementsByTag("p");
		Elements links2 = doc.select("div.mo");
		FileWriter fw = new FileWriter("out.txt");
		for(Element link : links){
			
			String linkText = link.text();
			fw.write(linkText);
			fw.write("\r\n");
			
		}
		for(Element link : links2){
			
			String linkText = link.text();
			
			fw.write(linkText+"\r\n");
			
		}
		fw.close();
		
		
		
	}
}
